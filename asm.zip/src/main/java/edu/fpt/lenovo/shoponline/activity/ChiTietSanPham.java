package edu.fpt.lenovo.shoponline.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.squareup.picasso.Picasso;

import java.text.DecimalFormat;
import java.util.ArrayList;

import edu.fpt.lenovo.shoponline.R;
import edu.fpt.lenovo.shoponline.model.Giohang;
import edu.fpt.lenovo.shoponline.model.Sanpham;

public class ChiTietSanPham extends AppCompatActivity {

    Toolbar toolbar;
    ImageView imganhsanpham;
    TextView txtTen, txtGia, txtMoTa;
    Spinner spinnerSoLuong;
    Button btnMua;
    int id=0;
    String Tendt="";
    int Giadt = 0;
    String Hinhanhdt="";
    String Mota="";
    int IdsanphamDT=0;

    void GetDataChiTiet(){
        //lấy key từ điện thoại activity
        Sanpham sanpham = (Sanpham)getIntent().getSerializableExtra("thongtinsanpham");
        // lấy dữ liệu trong mang
        id = sanpham.getID();
        Tendt = sanpham.getTensanpham();
        Giadt = sanpham.getGiasanpham();
        Hinhanhdt = sanpham.getHinhanhsanpham();
        Mota = sanpham.getMotasanpham();
        IdsanphamDT = sanpham.getIDSanpham();
        // Đưa sự kiện lấy được vào from
        txtTen.setText(Tendt);
        DecimalFormat decimalFormat = new DecimalFormat("###,###,###");
        txtGia.setText("Giá bán: "+decimalFormat.format(Giadt)+"VNĐ");
        txtMoTa.setText(Mota);
        Picasso.get().load(Hinhanhdt)
                .placeholder(R.drawable.home)
                .error(R.drawable.erro)
                .into(imganhsanpham);
    }
    void GetDataSpiner(){
        Integer[] soluong = new Integer[]{1,2,3,4,5,6,7,8,9,10};
        ArrayAdapter<Integer> arrayAdapter
                = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, soluong);
        spinnerSoLuong.setAdapter(arrayAdapter);
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chi_tiet_san_pham);

        Anhxa(); // ánh xạ với layout
        ActionToolbar(); // xử lý sự kiện click toolbar
        GetDataChiTiet(); // Lấy dữ liệu chi tiết dựa vào id
        GetDataSpiner(); // Số lượng
        EnventButtonGioHang(); // xử lý sự kiện button giỏ hàng

    }
    void EnventButtonGioHang(){
        btnMua.setOnClickListener(v -> {
            if (MainActivity.manggiohang.size()>0)
            {
                int sl = Integer.parseInt(spinnerSoLuong.getSelectedItem().toString());// Số lượng láy từ spiner
                boolean tonTaiMaHang = false;
                // Hàng lựa chọn đã có trong giỏ hàng
                for (int i=0; i < MainActivity.manggiohang.size(); i++)
                {
                    if (MainActivity.manggiohang.get(i).getIdsp()==id){// nếu có id
                        // Cũ cộng mới
                        MainActivity.manggiohang.get(i).setSoluongsp(MainActivity.manggiohang.get(i).getSoluongsp()+sl);
                        if (MainActivity.manggiohang.get(i).getSoluongsp() >= 10){
                            MainActivity.manggiohang.get(i).setSoluongsp(10);
                        }
                        // Giá
                        MainActivity.manggiohang.get(i).setGiasp(MainActivity.manggiohang.get(i).getSoluongsp()*Giadt);
                        tonTaiMaHang = true;
                    }
                }

                // Hàng lựa chọn chưa có trong giỏ hàng
                if (tonTaiMaHang ==false){
                    int sl1 = Integer.parseInt(spinnerSoLuong.getSelectedItem().toString());// Số lượng nhâp vào
                    long tien1 = sl1*Giadt;// Tính tiền
                    //thêm vào mảng giỏ hàng
                    MainActivity.manggiohang.add(new Giohang(id, Tendt, tien1, Hinhanhdt, sl1));
                }
            }
            else//khi kh có hàng
            {
                int sl2 = Integer.parseInt(spinnerSoLuong.getSelectedItem().toString());// Số lượng nhâp vào
                long tien2 = sl2*Giadt;// Tính tiền
                //thêm vào mảng giỏ hàng
                MainActivity.manggiohang.add(new Giohang(id, Tendt, tien2, Hinhanhdt, sl2));
            }
//            Intent intent = new Intent(getApplicationContext(), GioHangACtivity.class);
//            startActivity(intent);
        });
    }
    void  Anhxa(){
        toolbar = findViewById(R.id.toolbarchitietsanpham);
        imganhsanpham = findViewById(R.id.imageviewchitietsanpham);
        txtTen = findViewById(R.id.textviewtenchitietsanpham);
        txtGia = findViewById(R.id.textviewgiachitietsanpham);
        txtMoTa = findViewById(R.id.textviewmotachitietsanpham);
        spinnerSoLuong = findViewById(R.id.spinner);
        btnMua = findViewById(R.id.buttondatmua);
    }
    void ActionToolbar(){
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

}
