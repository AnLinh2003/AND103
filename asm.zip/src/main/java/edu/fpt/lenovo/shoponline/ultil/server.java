package edu.fpt.lenovo.shoponline.ultil;

public class server {
    // Thay localhost bằng địa chỉ IP của máy chủ
    public static String localhost = "http://10.24.38.179"; // Đảm bảo sử dụng http hoặc https đúng cách
    public static String Duongdanloaisp = "https://huongdanhoc.com/testmobile/getloaisp.php";
    public static String Duongdandienthoai = "https://huongdanhoc.com/testmobile/getsanpham.php?page=";
    public static String Duongdansanphammoinhat = "https://huongdanhoc.com/testmobile/getsanphammoinhat.php";
}

