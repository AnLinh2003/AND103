package edu.fpt.lenovo.shoponline.activity;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import edu.fpt.lenovo.shoponline.R;
import edu.fpt.lenovo.shoponline.adapter.DiethoaiAdapter;
import edu.fpt.lenovo.shoponline.model.Giohang;
import edu.fpt.lenovo.shoponline.model.Sanpham;
import edu.fpt.lenovo.shoponline.ultil.CheckConnetion;
import edu.fpt.lenovo.shoponline.ultil.server;

public class DienThoaiActivity extends AppCompatActivity implements DiethoaiAdapter.OnItemClickListener {
    public static ArrayList<Giohang> manggiohang;
    Toolbar toolbar;
    RecyclerView recyclerView;
    DiethoaiAdapter diethoaiAdapter;
    ArrayList<Sanpham> mangdienthoai;
    int idDienThoai = 0;
    int page = 1;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dien_thoai);
        Anhxa();//ánh xạ các ID
        ActionToolbarDienThoai();//xử lý click item trên toolbar
        GetIDLoaiSanPham();
        GetData(page);//lấy dữ liệu
    }

    void Anhxa() {
        toolbar = findViewById(R.id.toolbardienthoai);
        recyclerView = findViewById(R.id.recyclerviewdienthoai);
        mangdienthoai = new ArrayList<>();
        diethoaiAdapter = new DiethoaiAdapter(getApplicationContext(), mangdienthoai, this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(diethoaiAdapter);
    }

    void ActionToolbarDienThoai() {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationOnClickListener(view -> finish());
    }

    void GetIDLoaiSanPham() {
        idDienThoai = getIntent().getIntExtra("idloaidsanpham", -1);
    }

    void GetData(int p) {
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        String path = server.Duongdandienthoai + String.valueOf(p);
        StringRequest stringRequest = new StringRequest(Request.Method.POST, path, response -> {
            if (response != null) {
                try {
                    JSONArray jsonArray = new JSONArray(response);
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        int id = jsonObject.getInt("id");
                        String Tendt = jsonObject.getString("tensp");
                        int Giadt = jsonObject.getInt("giasp");
                        String Hinhanhdt = jsonObject.getString("hinhanhsp");
                        String Mota = jsonObject.getString("motasp");
                        int IdsanphamDT = jsonObject.getInt("idsanpham");

                        mangdienthoai.add(new Sanpham(id, Tendt, Giadt, Hinhanhdt, Mota, IdsanphamDT));
                        diethoaiAdapter.notifyDataSetChanged();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else {
                CheckConnetion.ShowToastLong(getApplicationContext(), "Không có dữ liệu");
            }
        }, error -> {
            // Handle the error
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                HashMap<String, String> param = new HashMap<>();
                param.put("idsanpham", String.valueOf(idDienThoai));
                return param;
            }
        };
        requestQueue.add(stringRequest);
    }

    @Override
    public void onItemClick(int position) {
        Intent intent = new Intent(getApplicationContext(), ChiTietSanPham.class);
        intent.putExtra("thongtinsanpham", mangdienthoai.get(position));
        startActivity(intent);
    }
}
