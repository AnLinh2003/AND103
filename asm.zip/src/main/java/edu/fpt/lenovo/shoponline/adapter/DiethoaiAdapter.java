package edu.fpt.lenovo.shoponline.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.text.DecimalFormat;
import java.util.ArrayList;

import edu.fpt.lenovo.shoponline.R;
import edu.fpt.lenovo.shoponline.model.Sanpham;

public class DiethoaiAdapter extends RecyclerView.Adapter<DiethoaiAdapter.ViewHolder> {
    private Context context;
    private ArrayList<Sanpham> sanphamArrayList;
    private OnItemClickListener onItemClickListener;

    public DiethoaiAdapter(Context context, ArrayList<Sanpham> sanphamArrayList, OnItemClickListener onItemClickListener) {
        this.context = context;
        this.sanphamArrayList = sanphamArrayList;
        this.onItemClickListener = onItemClickListener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_dienthoai, parent, false);
        return new ViewHolder(view, onItemClickListener);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Sanpham sanpham = sanphamArrayList.get(position);
        holder.txttendienthoai.setText(sanpham.getTensanpham());
        DecimalFormat decimalFormat = new DecimalFormat("###,###,###");
        holder.txtgiadienthoai.setText("Gia: " + decimalFormat.format(sanpham.getGiasanpham()));
        holder.txtmotadienthoai.setMaxLines(2);
        holder.txtmotadienthoai.setText(sanpham.getMotasanpham());
        Picasso.get().load(sanpham.getHinhanhsanpham())
                .placeholder(R.drawable.home)
                .error(R.drawable.erro)
                .into(holder.imgdienthoai);
    }

    @Override
    public int getItemCount() {
        return sanphamArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView txttendienthoai, txtgiadienthoai, txtmotadienthoai;
        ImageView imgdienthoai;
        OnItemClickListener onItemClickListener;

        public ViewHolder(@NonNull View itemView, OnItemClickListener onItemClickListener) {
            super(itemView);
            txttendienthoai = itemView.findViewById(R.id.textviewdienthoai);
            txtgiadienthoai = itemView.findViewById(R.id.textviewgiadienthoai);
            txtmotadienthoai = itemView.findViewById(R.id.textviewmotadienthoai);
            imgdienthoai = itemView.findViewById(R.id.imageviewdienthoai);
            this.onItemClickListener = onItemClickListener;
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            onItemClickListener.onItemClick(getAdapterPosition());
        }
    }

    public interface OnItemClickListener {
        void onItemClick(int position);
    }
}
