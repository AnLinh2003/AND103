//npm i nodemailer
//import thu vien
const express=require('express');
const mailer=require('nodemailer');
const app43=express();//tao doi tuong express
//tao thong tin nguoi gui
let transporter=mailer.createTransport({
    service: 'gmail',
    auth: {
        user: 'annttph23500@fpt.edu.vn',
        pass: 'omtk fcvc wptm fhih'
    }
});
//noi dung can gui
let mailOption={
    from: 'namlmph20982@fpt.edu.vn',
    to: 'annttph23500@fpt.edu.vn',
    subject: 'lab4 gửi mail',
    text: 'Mail gửi test lab4'
};
//thuc hien gui
transporter.sendMail(mailOption,(error,info)=>{
    if(error){
        console.error(error);
    }
    else{
        console.log("Thanh cong: ",info.messageId);
    }
});
//lang nghe
app43.listen(3002,()=>{
    console.log("server dang chay o cong 3002");
});