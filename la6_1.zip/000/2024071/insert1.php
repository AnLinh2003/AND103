<?php
$s = "localhost";
$u = "root";
$p = "";
$db = "a3";

// Kết nối đến cơ sở dữ liệu
$con = new mysqli($s, $u, $p, $db);

// Kiểm tra kết nối
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}

// Câu lệnh SQL với dấu ngoặc đóng đúng cú pháp
$sql = "INSERT INTO SanPham (MaSP, TenSP, MoTa) VALUES ('PH023', 'san pham289', 'Mo Ta 2982')";

// Thực hiện câu lệnh SQL và kiểm tra kết quả
if ($con->query($sql) === TRUE) {
    echo "Thành Công";
} else {
    echo "Lỗi: " . $con->error;
}

// Đóng kết nối
$con->close();
?>
