package com.example.demo2;

public class SvrResponseSanPham {
    //ket qua server tra ve
    private SanPham sanphams;
    private String message;

    public SanPham getSanphams() {
        return sanphams;
    }

    public String getMessage() {
        return message;
    }
}
